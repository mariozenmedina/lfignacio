import random


def gera_matriz(n):
    matriz = [[random.randint(1, 1024) for j in range(n)] for i in range(n)]
    return matriz


def maior_matriz(matriz):
    maior = matriz[0][0]
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            if matriz[i][j] > maior:
                maior = matriz[i][j]
    return maior


def menor_matriz(matriz):
    menor = matriz[0][0]
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            if matriz[i][j] < menor:
                menor = matriz[i][j]
    return menor

def media_matriz(matriz):
    soma = 0
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            soma += matriz[i][j]
    media = soma/((len(matriz))^2)
    return media


def ordena(coluna):
    n = len(coluna)
    for i in range(n - 1):
        for j in range(n - 1 - i):
            if coluna[j] > coluna[j + 1]:
                temp = coluna[j]
                coluna[j] = coluna[j + 1]
                coluna[j + 1] = temp
    return coluna


def escreve(matriz):
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            print(matriz[i][j], end=" ")
        print()
    return matriz


def ordena_colunas_matriz(matriz):
    n = len(matriz)
    j = 0
    while j < n:
        coluna = []
        for i in range(n):
            coluna.append(matriz[i][j])

        coluna_ordenada = ordena(coluna)

        for i in range(n):
            matriz[i][j] = coluna_ordenada[i]

        j += 1
    return matriz


def main():
    n = int(input())
    matriz = gera_matriz(n)

    print("Matriz original:")
    escreve(matriz)
    print()

    ordena_colunas_matriz(matriz)

    print("Matriz ordenada:")
    escreve(matriz)
    
    print()
    print("Maior elemento da matriz:")
    print(maior_matriz(matriz))

    print()
    print("Menor elemento da matriz:")
    print(menor_matriz(matriz))

    print()
    print("Média dos elementos da matriz:")
    print(media_matriz(matriz))


# chamada do programa principal
main()
