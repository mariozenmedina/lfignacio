def conta_ocorrencias(lista, x):
    # Caso base: lista vazia
    if len(lista) == 0:
        return 0
    # Caso recursivo: verifica o primeiro elemento e soma o resultado da chamada recursiva
    if lista[0] == x:
        return 1 + conta_ocorrencias(lista[1:], x)
    else:
        return conta_ocorrencias(lista[1:], x)


def main():
    n = int(input("Digite o tamanho da lista: "))
    lista = []
    for i in range(n):
        valor = int(input(f"Digite o {i+1}º valor: "))
        lista.append(valor)

    x = int(input("Digite o número a ser procurado: "))

    resultado = conta_ocorrencias(lista, x)
    print(f"O número {x} aparece {resultado} vez(es) na lista.")


main()
