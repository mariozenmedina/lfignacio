def eh_palindromo(palavra):
    # caso base: se a palavra tem 0 ou 1 caractere, é palíndroma
    if len(palavra) <= 1:
        return True
    # caso recursivo: compara o primeiro e o último caractere
    if palavra[0] != palavra[-1]:
        return False
    # chamada recursiva: verifica o "miolo" da palavra
    return eh_palindromo(palavra[1:-1])


def main():
    palavra = input("Digite uma palavra: ").lower()
    if eh_palindromo(palavra):
        print(f'A palavra "{palavra}" é palíndroma.')
    else:
        print(f'A palavra "{palavra}" não é palíndroma.')


main()
