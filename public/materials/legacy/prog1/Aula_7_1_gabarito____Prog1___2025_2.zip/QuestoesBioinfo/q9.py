tam = int(input())
mofit = input()
dna = input()

if tam > 50 or len(mofit) > 50 or len(dna) > 500:
    print("Valores não estão de acordo")
else:
    if len(mofit) > len(dna):
        resultado = ""
    else:
        resultado = ""
        for i in range(len(dna) - len(mofit) + 1):
            dna2_aux = dna[i:i + len(mofit)]

            dist = 0
            pos = ""
            p = 0
            while p < len(mofit):
                if mofit[p] != dna2_aux[p]:
                    pos += f"{p + 1} "
                    dist += 1
                p += 1

            if dist <= tam:
                resultado += f"\n{i + 1} {pos}"

    if resultado:
        print(f"As substrings com distância no máximo {tam} do mofit e as posições são: {resultado}")
    else:
        print("Valores não estão de acordo")
