k = int(input("Digite o valor de k: "))
n = int(input("Digite o valor de n: "))
s = input("Digite a sequência de DNA: ").upper()

i = 0
invalida = False
while i < len(s):
    ch = s[i]
    if ch != "A" and ch != "T" and ch != "G" and ch != "C":
        invalida = True
        break
    i += 1

if invalida:
    print("Sequência inválida")
else:
    substrings = []
    i = 0
    limite = len(s) - k + 1
    while i < limite:
        substrings.append(s[i:i+k])
        i += 1

    repetidas = []
    j = 0
    while j < len(substrings):
        sub = substrings[j]
        if substrings.count(sub) >= n and sub not in repetidas:
            repetidas.append(sub)
        j += 1

    if len(repetidas) == 0:
        print("Nenhuma substring aparece pelo menos " + str(n) + " vezes.")
    else:
        t = 0
        while t < len(repetidas):
            print(repetidas[t])
            t += 1
