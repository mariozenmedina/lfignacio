sequencia = input("Digite a sequência de DNA: ").upper()
k = int(input("Digite o valor de k: "))

i = 0
qtd_outras_letras = 0
pos_outras_letras = []

while i < len(sequencia):
    if sequencia[i] not in ["A", "T", "G", "C"]:
        pos_outras_letras.append(i + 1)  
        qtd_outras_letras += 1
    i += 1

if qtd_outras_letras != 0:
    print("Sequência inválida")
else:
    substrings_distintas = []
    i = 0
    limite = len(sequencia) - k + 1

    while i < limite:
        substring = sequencia[i:i + k]
        if substring not in substrings_distintas:
            substrings_distintas.append(substring)
        i += 1

    print(len(substrings_distintas))
