dna = list(input().upper())

dna_entrada = dna


n = len(dna)

for i in range(int(n/2)):
    aux = dna[i]
    dna[i] = dna[n-1-i]
    dna[n-1-i] = aux

valida = True
for i in range(n):
    if dna[i] == 'A':
        dna[i] = 'T'
    elif dna[i] == 'T':
        dna[i] = 'A'
    elif dna[i] == 'C':
        dna[i] = 'G'
    elif dna[i] == 'G':
        dna[i] = 'C'
    else:
        valida = False
        break

if valida:
    print(f"Dada a sequência {"".join(dna_entrada)}, seu reverso complementar é: {"".join(dna)}")
else:
    print("Sequência inválida")