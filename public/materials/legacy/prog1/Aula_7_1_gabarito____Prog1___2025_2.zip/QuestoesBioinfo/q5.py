dna = input().upper()
janela = int(input())
posicoes_erradas = []

if janela > len(dna):
    print("Sequência inválida")

else:
    for i in range(len(dna)):
        if dna[i] != 'A' and dna[i] != 'C' and dna[i] != 'G' and dna[i] != 'T':
            posicoes_erradas.append(i+1)

    if len(posicoes_erradas) == 0:
        porcentagem = []
        for i in range(len(dna) - janela +1):
            pedaco_dna = dna[i:janela+i]
            qtd_C_G = 0
            for j in range(janela):
                if pedaco_dna[j] == 'C' or pedaco_dna[j] == 'G':
                    qtd_C_G += 1
            porcentagem.append("%.2f" % (qtd_C_G / janela * 100))

        print(porcentagem)
    elif len(posicoes_erradas) == 1:
        print(f"Sequência inválida, pois na posição {i+1} o elemento não possui valor esperado.")
    else:
        print(f"Sequência inválida, pois nas posições {posicoes_erradas} os elementos não possuem valores esperados.")





