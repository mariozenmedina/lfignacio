dna = input().upper()
posicoes_erradas = []

for i in range(len(dna)):
    if dna[i] != 'A' and dna[i] != 'C' and dna[i] != 'G' and dna[i] != 'T':
        posicoes_erradas.append(i+1)

if len(posicoes_erradas) == 0:
    print("Seuqência válida.", end=" ")
    a = 0
    c = 0
    g = 0
    t = 0
    for i in range(len(dna)):
        if dna[i] == 'A':
            a += 1
        elif dna[i] == 'C':
            c += 1
        elif dna[i] == 'G':
            g += 1
        else:
            t += 1
    print(f"Além disso, a contagem de cada base nitrogenada é: A: {a} C: {c} G: {g} T: {t}")

elif len(posicoes_erradas) == 1:
    print(f"Sequência inválida, pois na posição {i+1} o elemento não possui valor esperado.")
else:
    print(f"Sequência inválida, pois nas posições {posicoes_erradas} os elementos não possuem valores esperados.")
