dna = list(input())

n = len(dna)

for i in range(int(n/2)):
    aux = dna[i]
    dna[i] = dna[n-1-i]
    dna[n-1-i] = aux

print("".join(dna))