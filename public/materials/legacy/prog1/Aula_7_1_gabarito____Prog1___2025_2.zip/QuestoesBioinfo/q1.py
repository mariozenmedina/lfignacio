dna = input().upper()
posicoes_erradas = []

for i in range(len(dna)):
    if dna[i] != 'A' and dna[i] != 'C' and dna[i] != 'G' and dna[i] != 'T':
        posicoes_erradas.append(i+1)

if len(posicoes_erradas) == 0:
    print("Seuqência válida.")
elif len(posicoes_erradas) == 1:
    print(f"Sequência inválida, pois na posição {i+1} o elemento não possui valor esperado.")
else:
    print(f"Sequência inválida, pois nas posições {posicoes_erradas} os elementos não possuem valores esperados.")
