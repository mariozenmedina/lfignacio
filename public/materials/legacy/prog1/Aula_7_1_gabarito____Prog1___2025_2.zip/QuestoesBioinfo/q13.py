s = input().upper()
c = input().upper()

valida_s = True
i = 0
while i < len(s):
    if s[i] != "A" and s[i] != "T" and s[i] != "G" and s[i] != "C":
        valida_s = False
        break
    i += 1

if (not valida_s) or (len(s) % 3 != 0):
    print("Sequência inválida ou |s| não é múltiplo de 3")
else:
    valida_c = False
    if len(c) == 3:
        valida_c = True

    j = 0
    while j < len(c) and valida_c:
        if c[j] != "A" and c[j] != "T" and c[j] != "G" and c[j] != "C":
            valida_c = False
            break
        j += 1

    if not valida_c:
        print("Códon alvo inválido")
    else:
        codons = []
        k = 0
        while k < len(s):
            codons.append(s[k:k+3])
            k += 3

        cont = 0
        t = 0
        while t < len(codons):
            if codons[t] == c:
                cont += 1
            t += 1

        print("[" + ", ".join(codons) + "], Contagem de " + c + ": " + str(cont))
