n = int(input())
k = int(input())

i = 0
soma = 0
while i <= k:
    fn = 1
    t = n
    while t > 0:
        fn *= t
        t -= 1

    fi = 1
    t = i
    while t > 0:
        fi *= t
        t -= 1

    fni = 1
    t = n - i
    while t > 0:
        fni *= t
        t -= 1

    comb = fn // (fi * fni)
    soma += comb
    i += 1

complemento = 2**n - soma

print("A quantidade de mRNAs com pelo menos " + str(k) + " exons dentre os " + str(n) + " exons é: " + str(complemento))
