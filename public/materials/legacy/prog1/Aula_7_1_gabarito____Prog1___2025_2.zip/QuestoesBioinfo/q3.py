dna = input()
posicoes_erradas = []

for i in range(len(dna)):
    if dna[i] != 'A' and dna[i] != 'a' and dna[i] != 'C' and dna[i] != 'c' and dna[i] != 'G' and dna[i] != 'g' and dna[i] != 'T' and dna[i] != 't':
        posicoes_erradas.append(i+1)

if len(posicoes_erradas) == 0:
    rna = ''
    for i in range(len(dna)):
        if dna[i] == 'A' or dna[i] == 'a' or dna[i] == 'C' or dna[i] == 'c' or dna[i] == 'G' or dna[i] == 'g':
            rna = rna + dna[i]
        elif dna[i] == 'T':
            rna = rna + 'U'
        else:
            rna = rna + 'u'
    print(rna)

elif len(posicoes_erradas) == 1:
    print(f"Sequência inválida, pois na posição {i+1} o elemento não possui valor esperado.")
else:
    print(f"Sequência inválida, pois nas posições {posicoes_erradas} os elementos não possuem valores esperados.")
