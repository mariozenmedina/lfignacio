rle = input().upper()

dna = ''
valida = True

for i in range(len(rle)):
    if rle[i] == 'A' or rle[i] == 'C' or rle[i] == 'G' or rle[i] == 'T':
        base = rle[i]
        pos = i + 1
        qtd = ''
        while pos < len(rle) and rle[pos] not in ['A', 'C', 'G', 'T']:
            if rle[pos] not in '0123456789':
                valida = False
                break
            qtd = qtd + rle[pos]
            pos += 1

        if not valida:
            break

        if qtd == '':
            valida = False
            break

        qtd = int(qtd) 

        if qtd <= 0:
            valida = False
            break

        dna = dna + base * qtd

if valida and dna != '':
    print(dna)
else:
    print("Entrada inválida")
