dna1 = input().upper()
dna2 = input().upper()

if len(dna1) == len(dna2):
    valida = True
    i = 0
    while i < len(dna1):
        if dna1[i] == 'A' or dna1[i] == 'C' or dna1[i] == 'G' or dna1[i] == 'T':
            i += 1
        else:
            print(f"A primeira sequência não é um DNA")
            valida = False
            break
    j = 0
    while j < len(dna2):
        if dna2[j] == 'A' or dna2[j] == 'C' or dna2[j] == 'G' or dna2[j] == 'T':
            j += 1
        else:
            print(f"A segunda sequência não é um DNA")
            valida = False
            break
    if valida:
        distancia = 0
        for i in range(len(dna1)):
            if dna1[i] != dna2[i]:
                distancia += 1
        print(f"Distância de Hamming entre {dna1} e {dna2} é: ", distancia)

else:
    print("Os genomas devem ter o mesmo tamanho")