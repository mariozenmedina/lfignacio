temps = {}
n = int(input("Digite o número de leituras de temperatura: "))

for k in range(n):
    cidade = input("Cidade: ")
    dia = input("Dia: ")
    temp = int(input("Temperatura: "))
    chave = (cidade, dia)
    temps[chave] = temp

cidade_consulta = input("Digite a cidade para calcular a média: ")

soma = 0
cont = 0
for chave in temps:
    if chave[0] == cidade_consulta:
        soma += temps[chave]
        cont += 1

if cont == 0:
    print("Não há dados para a cidade informada.")
else:
    media_temp = soma / cont
    print("Média das temperaturas de", cidade_consulta, "=", media_temp)
