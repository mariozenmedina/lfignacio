nome = input("Digite o nome: ")
idade = int(input("Digite a idade: "))
altura = float(input("Digite a altura: "))

dados = (nome, idade, altura)
n, i, a = dados

print("Nome:", n)
print("Idade:", i)
print("Altura:", a)