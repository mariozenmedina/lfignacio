def ordena_strings(lista):
    n = len(lista)
    for i in range(n - 1):
        indice_min = i
        for j in range(i + 1, n):
            if lista[j] < lista[indice_min]:
                indice_min = j
        if indice_min != i:
            aux = lista[i]
            lista[i] = lista[indice_min]
            lista[indice_min] = aux


def ordena_inteiros(lista):
    n = len(lista)
    for i in range(n - 1):
        indice_min = i
        for j in range(i + 1, n):
            if lista[j] < lista[indice_min]:
                indice_min = j
        if indice_min != i:
            aux = lista[i]
            lista[i] = lista[indice_min]
            lista[indice_min] = aux


frase = input("Digite uma frase: ")
palavras = frase.split()

freq = {}
for p in palavras:
    if p in freq:
        freq[p] += 1
    else:
        freq[p] = 1

lista_palavras = []
for p in freq:
    lista_palavras.append(p)

ordena_strings(lista_palavras)

print("Frequência das palavras (em ordem alfabética):")
for p in lista_palavras:
    print(p, "-", freq[p])