pares = {}
i = 0
while i < 5:
    nome = input("Digite o nome: ")
    if nome not in pares:
        telefone = input("Digite o telefone: ")
        pares[nome] = telefone
        i += 1
    else:
        print(f"{nome} já existe na Agenda, digite outro nome")


print("Agenda:")
for nome in pares:
    print(nome + ": " + str(pares[nome]))