n = int(input("Digite a quantidade de alunos (para preencher o dicionário): "))
notas = {}

for k in range(n):
    nome = input("Nome do aluno: ")
    nota = float(input("Nota do aluno: "))
    notas[nome] = nota

consulta = input("Digite o nome do aluno para consulta: ")
resultado = notas.get(consulta, None)

if resultado is None:
    print("Aluno não encontrado.")
else:
    print("Nota de", consulta, "=", resultado)