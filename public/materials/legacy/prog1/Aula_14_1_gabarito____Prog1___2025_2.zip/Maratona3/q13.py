def ordena_por_media_dec(lista):
    n = len(lista)
    for i in range(n - 1):
        indice_max = i
        for j in range(i + 1, n):
            # compara pelas médias (índice 1 da tupla)
            if lista[j][1] > lista[indice_max][1]:
                indice_max = j
        if indice_max != i:
            aux = lista[i]
            lista[i] = lista[indice_max]
            lista[indice_max] = aux

n = int(input("Digite a quantidade de alunos: "))
turma = {}

for k in range(n):
    nome = input("Nome do aluno: ")
    n1 = float(input("Nota 1: "))
    n2 = float(input("Nota 2: "))
    n3 = float(input("Nota 3: "))
    turma[nome] = (n1, n2, n3)

lista_medias = []

for nome in turma:
    notas_aluno = turma[nome]
    soma = notas_aluno[0] + notas_aluno[1] + notas_aluno[2]
    media = soma / 3.0
    lista_medias.append((nome, media))

ordena_por_media_dec(lista_medias)

print("Boletim (ordenado por média decrescente):")
for nome, media in lista_medias:
    if media >= 6.0:
        situacao = "APROVADO"
    elif media >= 4.0:
        situacao = "RECUPERAÇÃO"
    else:
        situacao = "REPROVADO"
    print(nome, "- média:", media, "-", situacao)