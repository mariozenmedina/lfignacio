def busca_binaria(lista, codigo, ini, fim):
    if ini > fim:
        return None
    meio = (ini + fim) // 2
    codigo_meio = lista[meio][0]

    if codigo_meio == codigo:
        return lista[meio][1]
    elif codigo < codigo_meio:
        return busca_binaria(lista, codigo, ini, meio - 1)
    else:
        return busca_binaria(lista, codigo, meio + 1, fim)

n = int(input("Digite a quantidade de produtos: "))
produtos = []

print("Digite os produtos em ordem crescente de código:")
for k in range(n):
    cod = int(input("Código do produto: "))
    preco = float(input("Preço do produto: "))
    produtos.append((cod, preco))

codigo_busca = int(input("Digite o código a ser buscado: "))

resultado = busca_binaria(produtos, codigo_busca, 0, n - 1)

if resultado is None:
    print("Produto não encontrado.")
else:
    print("Preço do produto de código", codigo_busca, "=", resultado)