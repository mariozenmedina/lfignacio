n = int(input("Digite a quantidade de alunos: "))
notas = {}

for k in range(n):
    nome = input("Nome do aluno: ")
    nota = float(input("Nota do aluno: "))
    notas[nome] = nota

soma = 0.0
for nome in notas:
    soma += notas[nome]

media = soma / n

print("Média da turma:", media)
print("Alunos acima da média:")
for nome in notas:
    if notas[nome] > media:
        print(nome, "-", notas[nome])