def caro(a, b, c):
    # Simulação de função "cara" com um laço
    s = 0
    i = 0
    while i < 100000:
        s += 1
        i += 1
    return a + b + c

def caro_com_cache(a, b, c, cache):
    chave = (a, b, c)
    if chave in cache:
        print("Resultado obtido do cache para", chave)
        return cache[chave]
    else:
        print("Calculando resultado novo para", chave)
        valor = caro(a, b, c)
        cache[chave] = valor
        return valor

cache = {}
q = int(input("Digite a quantidade de chamadas da função: "))

for i in range(q):
    a = int(input("a: "))
    b = int(input("b: "))
    c = int(input("c: "))
    resultado = caro_com_cache(a, b, c, cache)
    print("Resultado:", resultado)