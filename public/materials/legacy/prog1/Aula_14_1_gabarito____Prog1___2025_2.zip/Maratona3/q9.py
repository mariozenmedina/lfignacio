n = int(input("Digite a quantidade de alunos: "))
notas = {}

for k in range(n):
    nome = input("Nome do aluno: ")
    nota = float(input("Nota do aluno: "))
    notas[nome] = nota

agrupado = {}

for nome in notas:
    nota = notas[nome]
    if nota in agrupado:
        agrupado[nota].append(nome)
    else:
        agrupado[nota] = [nome]

print("Dicionário agrupado (nota -> lista de nomes):")
print(agrupado)

