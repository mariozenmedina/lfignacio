frase = input("Digite uma frase: ")
palavras = frase.split()

def ordena_inteiros(lista):
    n = len(lista)
    for i in range(n - 1):
        indice_min = i
        for j in range(i + 1, n):
            if lista[j] < lista[indice_min]:
                indice_min = j
        if indice_min != i:
            aux = lista[i]
            lista[i] = lista[indice_min]
            lista[indice_min] = aux


grupos = {}

for p in palavras:
    tamanho = len(p)
    if tamanho in grupos:
        grupos[tamanho].append(p)
    else:
        grupos[tamanho] = [p]

tamanhos = []
for t in grupos:
    tamanhos.append(t)

ordena_inteiros(tamanhos)

print("Palavras agrupadas por tamanho:")
for t in tamanhos:
    print("Tamanho", t, ":", grupos[t])
