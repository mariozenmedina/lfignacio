def fib(n, memo):
    if n in memo:
        return memo[n]
    if n == 0:
        resultado = 0
    elif n == 1:
        resultado = 1
    else:
        resultado = fib(n - 1, memo) + fib(n - 2, memo)
    memo[n] = resultado
    return resultado

n = int(input("Digite n para calcular Fibonacci(n): "))
memo = {}
print("Fibonacci(", n, ") =", fib(n, memo))