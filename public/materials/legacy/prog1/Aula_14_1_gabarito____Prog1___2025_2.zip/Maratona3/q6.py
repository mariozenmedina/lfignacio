n = int(input("Digite a quantidade de alunos: "))
notas = {}

for k in range(n):
    nome = input("Nome do aluno: ")
    nota = float(input("Nota do aluno: "))
    notas[nome] = nota

lista_tuplas = []
for nome in notas:
    lista_tuplas.append((nome, notas[nome]))

print("Lista de tuplas (nome, nota):")
print(lista_tuplas)