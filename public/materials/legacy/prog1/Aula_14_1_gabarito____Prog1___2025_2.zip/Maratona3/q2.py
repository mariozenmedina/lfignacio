def conta_letras(s):
    s = s.lower()
    conta = {}
    for c in s:
        if c == " ":
            continue
        if c in conta:
            conta[c] += 1
        else:
            conta[c] = 1
    return conta

texto = input("Digite uma frase: ")
dicionario_letras = conta_letras(texto)
print(dicionario_letras)