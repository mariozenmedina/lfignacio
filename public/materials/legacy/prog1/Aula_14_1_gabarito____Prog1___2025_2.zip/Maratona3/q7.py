def soma_esparsa(A, B):
    C = {}
    C["Número de Linhas"] = A["Número de Linhas"]
    C["Número de Colunas"] = A["Número de Colunas"]

    # Copia os elementos não-nulos de A
    for chave in A:
        if chave != "Número de Linhas" and chave != "Número de Colunas":
            C[chave] = A[chave]

    # Soma com os elementos de B
    for chave in B:
        if chave != "Número de Linhas" and chave != "Número de Colunas":
            valor_atual = 0
            if chave in C:
                valor_atual = C[chave]
            valor_atual = valor_atual + B[chave]

            if valor_atual != 0:
                C[chave] = valor_atual
            else:
                if chave in C:
                    del C[chave]

    return C

# Exemplo de uso:
A = {
    "Número de Linhas": 3,
    "Número de Colunas": 3,
    (0, 1): 2,
    (2, 2): 5
}
B = {
    "Número de Linhas": 3,
    "Número de Colunas": 3,
    (0, 1): 3,
    (1, 0): 4
}

C = soma_esparsa(A, B)
print("Matriz esparsa resultante (dicionário C):")
print(C)
