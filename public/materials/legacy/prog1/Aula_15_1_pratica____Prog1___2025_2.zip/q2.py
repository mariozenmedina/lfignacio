# Subprogramas
def mostra(msg, nm):
    print(msg)
    with open(nm, "r") as dados:
        for linhaLida in dados:
            print(linhaLida, end="")
    print()
    return None


def ehPrimo(n):
    for divisor in range(2, 1 + n // 2):
        if n % divisor == 0:
            return False
    return n > 1


def naoOcorrePrimos(nums):
    for num in nums:
        if ehPrimo(num):
            return False
    return True


def removeLinhasComPrimos(nm):
    # primeira passada: lê o arquivo original e grava apenas as linhas "válidas" em temp.txt
    with open(nm, "r") as dados, open("temp.txt", "w") as temporario:
        for linhaDeNumeros in dados:
            numeros = linhaDeNumeros.split()
            for i in range(len(numeros)):
                numeros[i] = int(numeros[i])
            if naoOcorrePrimos(numeros):
                temporario.write(linhaDeNumeros)

    # segunda passada: sobrescreve o arquivo original com o conteúdo de temp.txt
    with open(nm, "w") as dados, open("temp.txt", "r") as temporario:
        for linhaLida in temporario:
            dados.write(linhaLida)

    return None


# Principal
nomeArquivo = input()
mostra("Conteúdo do Arquivo %s:" % nomeArquivo, nomeArquivo)
removeLinhasComPrimos(nomeArquivo)
mostra("Conteúdo do Arquivo %s após eventuais remoções:" % nomeArquivo, nomeArquivo)
