def mostrar_conteudo_arquivo(nome_arquivo):
    print("Conteúdo do Arquivo:", nome_arquivo)
    with open(nome_arquivo, "r", encoding="utf-8") as f:
        for linha in f:
            print(linha, end="")
    print()  # linha em branco após o conteúdo


def constroi_dicionario_palavras(nome_arquivo, tamanho_minimo, tamanho_maximo):
    dicionario = {}

    with open(nome_arquivo, "r", encoding="utf-8") as f:
        for linha in f:
            # remove vírgulas
            linha_sem_virgula = linha.replace(",", "")
            palavras = linha_sem_virgula.split()

            for palavra in palavras:
                palavra_maiuscula = palavra.upper()
                if tamanho_minimo <= len(palavra_maiuscula) <= tamanho_maximo:
                    if palavra_maiuscula in dicionario:
                        dicionario[palavra_maiuscula] += 1
                    else:
                        dicionario[palavra_maiuscula] = 1

    return dicionario


def ordena_strings(lista):
    n = len(lista)
    for i in range(n - 1):
        indice_min = i
        for j in range(i + 1, n):
            if lista[j] < lista[indice_min]:
                indice_min = j
        if indice_min != i:
            aux = lista[i]
            lista[i] = lista[indice_min]
            lista[indice_min] = aux


def mostrar_dicionario_ordenado(dicionario):
    print("Dicionário de Palavras com Contagem de Ocorrências:")
    chaves = []
    for palavra in dicionario:
        chaves.append(palavra)

    ordena_strings(chaves)

    for palavra in chaves:
        qtd = dicionario[palavra]
        if qtd == 1:
            print(f"{palavra} ocorreu 1 vez")
        else:
            print(f"{palavra} ocorreu {qtd} vezes")


def main():
    nome_arquivo = input().strip()
    linha_tamanhos = input().split()
    tamanho_minimo = int(linha_tamanhos[0])
    tamanho_maximo = int(linha_tamanhos[1])

    mostrar_conteudo_arquivo(nome_arquivo)
    dicionario = constroi_dicionario_palavras(nome_arquivo, tamanho_minimo, tamanho_maximo)
    mostrar_dicionario_ordenado(dicionario)


if __name__ == "__main__":
    main()
