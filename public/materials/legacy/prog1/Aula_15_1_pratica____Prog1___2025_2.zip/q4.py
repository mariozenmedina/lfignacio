def imprime_matriz(matriz):
    print("Matriz lida:")
    for linha in matriz:
        print(*linha)


def busca_recursiva(matriz, x, lin, col, posicoes):
    # Caso base: terminou as linhas
    if lin == len(matriz):
        return 0

    # Se terminou as colunas, avança para a próxima linha
    if col == len(matriz[0]):
        return busca_recursiva(matriz, x, lin + 1, 0, posicoes)

    # Conta a ocorrência atual
    ocorrencias = 0
    if matriz[lin][col] == x:
        ocorrencias = 1
        posicoes.append((lin + 1, col + 1))  # posições começam em 1

    # Avança recursivamente para a próxima célula
    return ocorrencias + busca_recursiva(matriz, x, lin, col + 1, posicoes)


def main():
    # Leitura da matriz
    L, C = map(int, input().split())
    matriz = []
    for _ in range(L):
        linha = list(map(int, input().split()))
        matriz.append(linha)

    x = int(input())

    imprime_matriz(matriz)
    print()

    # Lista para armazenar posições encontradas
    posicoes = []

    total = busca_recursiva(matriz, x, 0, 0, posicoes)

    print(f"{x} ocorre {total} vez(es) na matriz")
    if total > 0:
        print("Posições:")
        for (i, j) in posicoes:
            print(f"Linha {i}, Coluna {j}")


if __name__ == "__main__":
    main()
