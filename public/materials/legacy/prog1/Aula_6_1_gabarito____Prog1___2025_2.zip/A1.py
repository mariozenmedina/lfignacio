# Leia 5 números, imprima a lista e o tamanho
lista = []
i = 0
while i < 5:
    lista.append(int(input()))
    i += 1
print(lista)
print(len(lista))
