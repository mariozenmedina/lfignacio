# Leia n, depois n números; calcule soma e média
n = int(input())
lista = []
i = 0
while i < n:
    lista.append(int(input()))
    i += 1

soma = 0
i = 0
while i < len(lista):
    soma += lista[i]
    i += 1

media = soma / len(lista)
print("soma =", soma, "media =", media)
