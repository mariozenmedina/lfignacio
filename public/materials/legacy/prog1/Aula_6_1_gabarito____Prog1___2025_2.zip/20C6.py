# Leia frase (sem acentos/pontuação), ignore espaços e teste palíndromo
frase = input().lower()
letras = []
i = 0
while i < len(frase):
    ch = frase[i]
    if ch != " ":
        letras.append(ch)
    i += 1

pal = True
i = 0
j = len(letras) - 1
while i < j:
    if letras[i] != letras[j]:
        pal = False
        break
    i += 1
    j -= 1
print(pal)
