# Comprimento da sequência crescente contígua mais longa
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i])); i += 1

if len(lista) == 0:
    print(0)
else:
    melhor = 1
    atual = 1
    i = 1
    while i < len(lista):
        if lista[i] > lista[i-1]:
            atual += 1
        else:
            if atual > melhor:
                melhor = atual
            atual = 1
        i += 1
    if atual > melhor:
        melhor = atual
    print(melhor)
