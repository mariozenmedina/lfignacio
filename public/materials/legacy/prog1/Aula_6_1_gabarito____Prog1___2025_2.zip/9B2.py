# Ordenação por seleção
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i]))
    i += 1

n = len(lista)
i = 0
while i < n:
    # encontra o índice do menor elemento em [i..n-1]
    idx_min = i
    j = i + 1
    while j < n:
        if lista[j] < lista[idx_min]:
            idx_min = j
        j += 1
    # coloca o menor na posição i (troca)
    aux = lista[i]
    lista[i] = lista[idx_min]
    lista[idx_min] = aux
    i += 1

print(lista)
