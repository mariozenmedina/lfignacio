# Reordene: < pivô, == pivô, > pivô
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i])); i += 1
pivo = int(input())

men = []
igu = []
mai = []
i = 0
while i < len(lista):
    v = lista[i]
    if v < pivo:
        men.append(v)
    elif v == pivo:
        igu.append(v)
    else:
        mai.append(v)
    i += 1
lista = men + igu + mai
print(lista)
