# Leia a lista em uma linha e depois x; imprima índices onde x aparece
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i]))
    i += 1

x = int(input())
encontrou = False
i = 0
while i < len(lista):
    if lista[i] == x:
        print(i, end=" ")
        encontrou = True
    i += 1
if not encontrou:
    print("nao encontrado")
else:
    print()
