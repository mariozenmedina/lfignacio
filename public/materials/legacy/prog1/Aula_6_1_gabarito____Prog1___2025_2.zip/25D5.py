# Palavra secreta e palpites por letra; 6 tentativas
palavra = input("Palavra secreta: ").lower()

letras = []
i = 0
while i < len(palavra):
    letras.append(palavra[i])
    i += 1

estado = []
i = 0
while i < len(letras):
    if letras[i] == " ":
        estado.append(" ")
    else:
        estado.append("_")
    i += 1

tentativas = 6
usadas = []

while tentativas > 0 and "_" in estado:
    print("Estado:", end=" ")
    i = 0
    while i < len(estado):
        print(estado[i], end=" ")
        i += 1
    print(" | Tentativas:", tentativas)

    palpite = input("Letra: ").lower().strip()
    if palpite == "" or len(palpite) != 1:
        print("Digite uma única letra.")
        continue
    if palpite in usadas:
        print("Você já tentou essa letra.")
        continue
    usadas.append(palpite)

    acertou = False
    i = 0
    while i < len(letras):
        if letras[i] == palpite:
            estado[i] = palpite
            acertou = True
        i += 1
    if not acertou:
        tentativas -= 1

if "_" not in estado:
    print("Parabéns! Você acertou: ", end="")
    i = 0
    while i < len(estado):
        print(estado[i], end="")
        i += 1
    print()
else:
    print("Fim! A palavra era: ", end="")
    i = 0
    while i < len(letras):
        print(letras[i], end="")
        i += 1
    print()
