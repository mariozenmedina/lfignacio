# Inverta trocando pontas até o meio
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i])); i += 1

i = 0
j = len(lista) - 1
while i < j:
    aux = lista[i]
    lista[i] = lista[j]
    lista[j] = aux
    i += 1
    j -= 1
print(lista)
