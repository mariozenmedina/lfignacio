# Leia n e n números; encontre menor e maior varrendo a lista
n = int(input())
lista = []
i = 0
while i < n:
    lista.append(int(input()))
    i += 1

menor = lista[0]
maior = lista[0]
i = 1
while i < len(lista):
    if lista[i] < menor:
        menor = lista[i]
    if lista[i] > maior:
        maior = lista[i]
    i += 1
print("menor =", menor, "maior =", maior)
