# Elementos que estão em exatamente uma das listas (ordem preservada)
A_txt = input().split()
B_txt = input().split()

A = []
i = 0
while i < len(A_txt):
    A.append(int(A_txt[i])); i += 1
B = []
i = 0
while i < len(B_txt):
    B.append(int(B_txt[i])); i += 1

res = []
i = 0
while i < len(A):
    if (A[i] not in B) and (A[i] not in res):
        res.append(A[i])
    i += 1
i = 0
while i < len(B):
    if (B[i] not in A) and (B[i] not in res):
        res.append(B[i])
    i += 1
print(res)
