# Produza [[valor, contagem], ...] para runs consecutivos
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i])); i += 1

res = []
if len(lista) == 0:
    print(res)
else:
    atual = lista[0]
    cont = 1
    i = 1
    while i < len(lista):
        if lista[i] == atual:
            cont += 1
        else:
            res.append([atual, cont])
            atual = lista[i]
            cont = 1
        i += 1
    res.append([atual, cont])
    print(res)
