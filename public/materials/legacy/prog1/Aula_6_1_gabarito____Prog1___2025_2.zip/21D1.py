# Leia lista e k; mantenha lista 'top' (desc) de tamanho <= k
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i])); i += 1
k = int(input())

top = []  # sempre em ordem decrescente
i = 0
while i < len(lista):
    v = lista[i]
    pos = 0
    while pos < len(top) and top[pos] >= v:
        pos += 1
    if len(top) < k:
        top.insert(pos, v)
    else:
        if k > 0 and v > top[-1]:
            top.insert(pos, v)
            while len(top) > k:
                top.pop()
    i += 1
print(top)
