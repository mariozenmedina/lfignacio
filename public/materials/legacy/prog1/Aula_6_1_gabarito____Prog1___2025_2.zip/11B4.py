# Construa nova lista sem repetir elementos
partes = input().split()
orig = []
i = 0
while i < len(partes):
    orig.append(int(partes[i]))
    i += 1

semdup = []
i = 0
while i < len(orig):
    if orig[i] not in semdup:
        semdup.append(orig[i])
    i += 1
print(semdup)
