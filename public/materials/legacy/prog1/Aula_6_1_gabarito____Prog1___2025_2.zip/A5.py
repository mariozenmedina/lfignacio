# Leia n e a lista; conte pares e ímpares
n = int(input())
lista = []
i = 0
while i < n:
    lista.append(int(input()))
    i += 1

pares = 0
impares = 0
i = 0
while i < len(lista):
    if lista[i] % 2 == 0:
        pares += 1
    else:
        impares += 1
    i += 1
print("pares =", pares, "impares =", impares)
