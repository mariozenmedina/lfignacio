# Leia a lista e depois x; remova TODAS as ocorrências de x
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i]))
    i += 1

x = int(input())
while True:
    if x in lista:
        lista.remove(x)
    else:
        break
print(lista)
