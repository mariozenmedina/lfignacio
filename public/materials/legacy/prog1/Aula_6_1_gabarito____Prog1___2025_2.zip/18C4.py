# Conte frequências de 0 a 10 em uma lista de contagem de tamanho 11
partes = input().split()
notas = []
i = 0
while i < len(partes):
    notas.append(int(partes[i])); i += 1

freq = [0] * 11
i = 0
while i < len(notas):
    v = notas[i]
    if 0 <= v <= 10:
        freq[v] += 1
    i += 1
print(freq)
