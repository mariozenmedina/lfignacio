# Segundo menor e segundo maior usando seleção do mínimo
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i]))
    i += 1

n = len(lista)

# ordena por seleção (mesmo algoritmo da Q9)
i = 0
while i < n:
    idx_min = i
    j = i + 1
    while j < n:
        if lista[j] < lista[idx_min]:
            idx_min = j
        j += 1
    aux = lista[i]
    lista[i] = lista[idx_min]
    lista[idx_min] = aux
    i += 1

if n < 2:
    print("sem segundo menor/maior")
else:
    print("segundo menor =", lista[1])
    print("segundo maior =", lista[n-2])
