# True se cada próximo > anterior
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i])); i += 1

cresc = True
i = 1
while i < len(lista):
    if not (lista[i] > lista[i-1]):
        cresc = False
        break
    i += 1
print(cresc)
