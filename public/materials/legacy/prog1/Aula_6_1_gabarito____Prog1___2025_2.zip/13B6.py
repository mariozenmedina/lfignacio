# Leia lista e k; rotacione à direita por k
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i])); i += 1
k = int(input())

n = len(lista)
if n > 0:
    k = k % n
    lista = lista[-k:] + lista[:-k]
print(lista)
