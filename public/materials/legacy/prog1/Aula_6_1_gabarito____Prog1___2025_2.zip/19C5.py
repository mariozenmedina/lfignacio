# Leia 9 números em uma linha; monte matriz 3x3 e some
nums = input().split()
vals = []
i = 0
while i < len(nums):
    vals.append(int(nums[i])); i += 1

mat = [vals[0:3], vals[3:6], vals[6:9]]

# somas das linhas
i = 0
while i < 3:
    s = 0
    j = 0
    while j < 3:
        s += mat[i][j]
        j += 1
    print("linha", i, "=", s)
    i += 1

# somas das colunas
j = 0
while j < 3:
    s = 0
    i = 0
    while i < 3:
        s += mat[i][j]
        i += 1
    print("coluna", j, "=", s)
    j += 1

# diagonais
s = mat[0][0] + mat[1][1] + mat[2][2]
print("diag_principal =", s)
s = mat[0][2] + mat[1][1] + mat[2][0]
print("diag_secundaria =", s)
