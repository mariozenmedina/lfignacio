# Intercale elementos: A[0],B[0],A[1],B[1],...
A_txt = input().split()
B_txt = input().split()

A = []
i = 0
while i < len(A_txt):
    A.append(int(A_txt[i])); i += 1
B = []
i = 0
while i < len(B_txt):
    B.append(int(B_txt[i])); i += 1

C = []
i = 0
while i < len(A) or i < len(B):
    if i < len(A):
        C.append(A[i])
    if i < len(B):
        C.append(B[i])
    i += 1
print(C)
