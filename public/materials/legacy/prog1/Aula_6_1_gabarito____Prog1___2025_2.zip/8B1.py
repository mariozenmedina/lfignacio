# Leia números separados por espaço e converta para int
partes = input().split()
lista = []
i = 0
while i < len(partes):
    lista.append(int(partes[i]))
    i += 1
print(lista)
