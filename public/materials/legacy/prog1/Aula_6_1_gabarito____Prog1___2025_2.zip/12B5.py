# Leia A e B; união e interseção sem repetir na interseção
A_txt = input().split()
B_txt = input().split()

A = []
i = 0
while i < len(A_txt):
    A.append(int(A_txt[i])); i += 1
B = []
i = 0
while i < len(B_txt):
    B.append(int(B_txt[i])); i += 1

uniao = []
i = 0
while i < len(A):
    if A[i] not in uniao:
        uniao.append(A[i])
    i += 1
i = 0
while i < len(B):
    if B[i] not in uniao:
        uniao.append(B[i])
    i += 1

inter = []
i = 0
while i < len(A):
    if (A[i] in B) and (A[i] not in inter):
        inter.append(A[i])
    i += 1

print("uniao =", uniao)
print("intersecao =", inter)
