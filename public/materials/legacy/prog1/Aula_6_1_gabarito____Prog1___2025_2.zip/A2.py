# Leia 5 números e troque o primeiro com o último
lista = []
i = 0
while i < 5:
    lista.append(int(input()))
    i += 1

aux = lista[0]
lista[0] = lista[4]
lista[4] = aux
print(lista)
